# Transmission Environment for Site Technology
#                  TEST (API)


import json
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
from fastapi import Path
from datetime import datetime
from fastapi.middleware.cors import CORSMiddleware
import subprocess
import mysql.connector

#create the API
app = FastAPI()



#used for removing unnessecary values from the JSON analysis
def remove_elements_by_key(data):
    try:
        if isinstance(data, list):
            return [remove_elements_by_key(item) for item in data]
        elif isinstance(data, dict):
            keys_to_remove = ["elements", "markdown", "id", "first_markdown_element", "error"]
            for key in keys_to_remove:
                if key in data:
                    del data[key] 
            for key, value in data.items():
                data[key] = remove_elements_by_key(value)
            return data
        else:
            return data
    except Exception as e:
        print("Error is: ", str(e))

#this will remove unneeded parts (such as the ASCII graph) from the summary
def format_summary(data):
    midway = data.partition('Total')
    summary = midway[1] + midway[2]
    endway = summary.partition('ERC')
    summarypt1 = endway[0]
    summarypt2 = endway[2].partition('INFO')
    summary = summarypt1 + summarypt2[1] + summarypt2[2]
    return summary

#this allows us to run commands such as slither-related commands
def run_cmd(command):
    try:
        result = subprocess.run(command,text=True,capture_output=True,shell=True)
        return result
    except subprocess.CalledProcessError as e:
        print(f"Command '{''.join(command)}' failed with error:\n", str(e))
    except Exception as e:
        print("Error is: ", str(e))
    

def slither_eval(file):
    try:
        #run_cmd('solc-select install 0.8.5') may need to be installed depending on if you followed the instructions or not
        run_cmd('solc-select use 0.8.5')
        filename = file.partition('.')
        analysis = run_cmd('slither '+file+' --json -')
        #print(analysis.stdout)
        summary = subprocess.run('slither '+file+' --print human-summary',text=True,capture_output=True,shell=True)
        return analysis, summary
    except subprocess.CalledProcessError as e:
        print(f"Command '{''.join(Command)}' failed with error:\n", str(e))
    except Exception as e:
        print("Error is: ", str(e))

#used for the uploads page
def insert_data_to_database(data):
    db_connection = mysql.connector.connect(
    host="0.0.0.0",
    port='3306',
    user="root",
    password="P@55w0rd",
    database="cos349assign2"
    )
    db_cursor = db_connection.cursor()
    
    #sql injection prevention
    sql = "INSERT into reports (reportName, analysis, uploaded_datetime, summary) VALUES (%s, %s, %s, %s)"
    values = (data["uploaded_filename"], data["json_formatted"], data["uploaded_datetime"], data["summary"])
    db_cursor.execute(sql, values)
    db_connection.commit()

@app.post("/remediation/")
async def remediation(file: UploadFile = File(...), other_data: str = None):
    # Read the contents of the uploaded file
    file_contents = file.file.read()

    # Process the uploaded file using slither
    uploaded_filename = file.filename
    analysis, summary = slither_eval(uploaded_filename)

    # format and reduce unnecessary output
    with open('Unparsed.json', 'w') as f:
        f.write(analysis.stdout)

    with open('Unparsed.json', 'r') as f:
        data = json.load(f)

    text = remove_elements_by_key(data)
    json_formatted = json.dumps(text, indent=2)

    # Generate the uploaded_datetime as the current time
    uploaded_datetime = datetime.now().isoformat()

    # create the summary text
    summary = format_summary(summary.stderr)

    result_data = {
        "uploaded_filename": uploaded_filename,
        "json_formatted": json_formatted,
        "uploaded_datetime": uploaded_datetime,
        "summary": summary
    }


    insert_data_to_database(result_data)

    return {"message": "File uploaded and processed", "data": result_data}

@app.get("/get_all_results/")
async def get_all_results():
    try:
        # Connect to the database
        db_connection = mysql.connector.connect(
            host="0.0.0.0",
            port='3306',
            user="root",
            password="P@55w0rd",
            database="cos349assign2"
        )

        # Create a cursor to execute SQL queries
        db_cursor = db_connection.cursor()

        # Select all records from the results table
        sql = "SELECT reportID, reportname, uploaded_datetime FROM reports"
        db_cursor.execute(sql)

        # Fetch all the records
        records = db_cursor.fetchall()

        # Close the database connection
        db_connection.close()

        # If there are records, return them as JSON
        if records:
            results_list = []
            for record in records:
                result_dict = {
                    "reportID": record[0],
                    "reportName": record[1],
                    "upload_datetime": record[2].isoformat()
                }
                results_list.append(result_dict)

            return JSONResponse(content={"message": "Records retrieved successfully", "data": results_list})
        else:
            return JSONResponse(content={"message": "No records found", "data": []})

    except Exception as e:
        return JSONResponse(content={"message": f"Error: {str(e)}", "data": []})

# Configure CORS this is to allow the returned database information to be displayed on the website
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with your allowed origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

#the report_id is passed by the website when this API function is called
@app.get("/get_report/{report_id}")
async def get_report(report_id: int = Path(...)):
    try:
        # Connect to the database
        db_connection = mysql.connector.connect(
            host="0.0.0.0",
            port='3306',
            user="root",
            password="P@55w0rd",
            database="cos349assign2"
        )

        # Create a cursor to execute SQL queries
        db_cursor = db_connection.cursor()

        # Select the record with the given reportID
        sql = "SELECT * FROM reports WHERE reportID = %s"
        db_cursor.execute(sql, (report_id,))

        # Fetch the record, noting only one is needed
        record = db_cursor.fetchone()

        # Close the database connection
        db_connection.close()

        # If a record is found, return it as JSON
        if record:
            result_dict = {
                "reportID": record[0],
                "reportName": record[1],
                "analysis": record[2],  # Adjust the column index based on our database schema
                "uploaded_datetime": record[3].isoformat(),
                "summary": record[4],  # Adjust the column index based on our database schema
            }

            return JSONResponse(content={"message": "Report retrieved successfully", "data": result_dict})
        else:
            return JSONResponse(content={"message": "Report not found", "data": {}})

    except Exception as e:
        return JSONResponse(content={"message": f"Error: {str(e)}", "data": {}})

#this will retrieve the vulnerabilities as needed
@app.get("/remediation/{check}")
async def get_remedy(check: str = Path(...)):
    try:
        # Connect to the database
        db_connection = mysql.connector.connect(
            host="0.0.0.0",
            port='3306',
            user="root",
            password="P@55w0rd",
            database="cos349assign2"
        )

        # Create a cursor to execute SQL queries
        db_cursor = db_connection.cursor()

        # Select the record with the given reportID
        sql = "SELECT remediationText FROM remediation WHERE vulnerabilityText = %s"
        db_cursor.execute(sql, (check,))

        # Fetch the record
        record = db_cursor.fetchone()

        # Close the database connection
        db_connection.close()

        # If a record is found, return it as JSON
        if record:
            result_dict = {
                "remediationText": record[0]
            }

            return JSONResponse(content={"message": "Report retrieved successfully", "data": result_dict})
        else:
            return JSONResponse(content={"message": "Report not found", "data": {}})

    except Exception as e:
        return JSONResponse(content={"message": f"Error: {str(e)}", "data": {}})

