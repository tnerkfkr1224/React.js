import * as Mat from '@mui/material';
import React,{ useEffect, useState } from "react";
import { Link } from 'react-router-dom'; 
import axios from 'axios';


const ReportGrid = () => { 
  const [Data,setData] = useState([]);

  useEffect(() => {
    //Fetch data from the API when the compoenet mounts
    axios.get('http://localhost:8000/get_all_results/') //Replace with your URL here
    .then((response) => {
      setData(response.data.data); //set the fetched data in the state
      console.log(response.data)
    })
    .catch((error)=> {
      console.error('Error fetching data:',error)
    });
},[]);   
  
  
return (
    <Mat.Box align="center" display="flex" alignItems="center">
      <Mat.Grid container spacing={5} style={{ display: 'flex', justifyContent: 'center' }}>
        {Data.map((item, index) => (
          <Mat.Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={index}>
            <Mat.Box justifyContent="center" alignContent='center'>
              <Mat.Paper elevation={5}>
                <Mat.Typography sx={{ paddingTop: '10px' }}>
                  <img
                    src={require('../../assets/images/249-2496828_computer-icons-report-royaltyfree-black-text-png-report.jpg')} alt="clipart of report"
                    width="100" height="120"
                  />
                </Mat.Typography>
                <Mat.Typography variant="h5">
                  <p>{item.reportName}</p>
                </Mat.Typography>
                <Mat.Typography variant="caption">
                  uploaded at: {item.upload_datetime}
                </Mat.Typography>
                <Mat.Typography>
                  <p>ReportID: {item.reportID}</p>
                </Mat.Typography>
                <Link to={`/srd/${item.reportID}`} style={{ textDecoration: 'none' }}>
                  {/* Use Link component to navigate to the VulnsList page with reportID */}
                  {/* The URL path should match route configuration */}
                  <Mat.Button sx={{ mb: 2 }} variant="outlined" color="secondary">
                  View Report
                  </Mat.Button>
                </Link>
              </Mat.Paper>
            </Mat.Box>
          </Mat.Grid>
        ))}
      </Mat.Grid>
    </Mat.Box>
  );
};
export default ReportGrid;


