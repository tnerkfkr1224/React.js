import React from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom'; // Import Routes
import Upload from './views/Upload/index.js'; //homepage
import ReportArea from './views/ReportSearch/index.js'; //list of reports
import SRD from './views/Reports/SingleReportDisplay.js'; //details for a specific report
import './assets/styles/global-styles.css'; 

function RedirectComp() {
  const navigate = useNavigate();
  navigate('/srd')
 
}

function App() {
  return (
    <Router>
     <Routes> {/*Provide the list of pages and the addresses to store them at for use by react-router*/}
        <Route path="/" exact element={<Upload />} />
        <Route path="/reportarea" element={<ReportArea />} />
        <Route path="/srd/:reportID" element={<SRD />} />
    
      </Routes>
    </Router>
  );
}

export default App;
